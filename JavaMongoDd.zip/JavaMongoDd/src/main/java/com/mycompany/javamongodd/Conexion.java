/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javamongodd;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import java.util.List;
import javax.swing.JOptionPane;
/**
 *
 * @author itzel
 */
public class Conexion {
    public MongoClient crearConexion(){
        MongoClient mongo=null;
        String servidor="localhost";
        Integer puerto=27017;
        try{
            mongo=new MongoClient(servidor,puerto);
            List<String> NombreBaseDatos=mongo.getDatabaseNames();
            JOptionPane.showMessageDialog(null, "Se conecto correctamente a mongodb"+NombreBaseDatos.toString());
            
        }catch(MongoException e){
            JOptionPane.showMessageDialog(null, "Error de conextion con mongodb, error"+e.toString());
        }
        return mongo;
    }
}
