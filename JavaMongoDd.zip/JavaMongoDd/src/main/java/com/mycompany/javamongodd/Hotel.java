/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javamongodd;

/**
 *
 * @author itzel
 */
import java.util.List;

public class Hotel {
    private String id;
    private String nombre;
    private String direccion;
    private List<Habitacion> habitaciones;

    // Constructor
    public Hotel(String id, String nombre, String direccion, List<Habitacion> habitaciones) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.habitaciones = habitaciones;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public List<Habitacion> getHabitaciones() {
        return habitaciones;
    }
}
