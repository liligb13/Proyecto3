/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javamongodd;

/**
 *
 * @author itzel
 */

public class Habitacion {
    private String tipo;
    private double tarifa;
    private boolean disponible;

    public Habitacion(String tipo, double tarifa) {
        this.tipo = tipo;
        this.tarifa = tarifa;
        this.disponible = true;
    }

    public String getTipo() {
        return tipo;
    }

    public double getTarifa() {
        return tarifa;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void reservar() {
        this.disponible = false;
    }
}