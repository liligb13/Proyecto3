/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javamongodd;

/**
 *
 * @author itzel
 */
public class Tarifa {
    private String id;
    private double monto;
    private String tipo;
    private String idCategoria;

    // Constructor
    public Tarifa(String id, double monto, String tipo, String idCategoria) {
        this.id = id;
        this.monto = monto;
        this.tipo = tipo;
        this.idCategoria = idCategoria;
    }

    // Getters
    public String getId() {
        return id;
    }

    public double getMonto() {
        return monto;
    }

    public String getTipo() {
        return tipo;
    }

    public String getIdCategoria() {
        return idCategoria;
    }
}
