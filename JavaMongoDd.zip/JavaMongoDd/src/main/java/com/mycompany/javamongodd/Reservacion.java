/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javamongodd;

/**
 *
 * @author itzel
 */
public class Reservacion {
    private String id;
    private String fechaInicio;
    private String fechaFin;
    private double montoTotal;
    private String idCliente;
    private String idHabitacion;
    private String idTarifa;

    // Constructor
    public Reservacion(String id, String fechaInicio, String fechaFin, double montoTotal,
                       String idCliente, String idHabitacion, String idTarifa) {
        this.id = id;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.montoTotal = montoTotal;
        this.idCliente = idCliente;
        this.idHabitacion = idHabitacion;
        this.idTarifa = idTarifa;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public String getIdHabitacion() {
        return idHabitacion;
    }

    public String getIdTarifa() {
        return idTarifa;
    }
}
