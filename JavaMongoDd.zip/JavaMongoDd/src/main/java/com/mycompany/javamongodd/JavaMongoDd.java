/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javamongodd;

/**
 *
 * @author itzel
 */
public class JavaMongoDd {

    public static void main(String[] args) {
        Conexion conex=new Conexion();
        conex.crearConexion();
    }
}
