/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author itzel
 */
import com.mycompany.javamongodd.Reservacion;
import java.util.ArrayList;
import java.util.List;

public class ReservacionDAO {

    public List<Reservacion> obtenerReservaciones() {
        // Simula obtener reservaciones de MongoDB
        List<Reservacion> reservaciones = new ArrayList<>();
        reservaciones.add(new Reservacion("656af26d58bd764de8aaccb5", "2023-01-01", "2023-01-05", 200,
                "generadoAutomanticamentePorMongoDBCompass",
                "generadoAutomanticamentePorMongoDBCompass",
                "generadoAutomanticamentePorMongoDBCompass"));
        return reservaciones;
    }
}

