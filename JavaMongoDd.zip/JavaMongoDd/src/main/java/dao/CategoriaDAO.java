/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author itzel
 */
import com.mycompany.javamongodd.Categoria;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    public List<Categoria> obtenerCategorias() {
       
        List<Categoria> categorias = new ArrayList<>();
        categorias.add(new Categoria("656af23e58bd764de8aaccac", "Categoría Individual", "Habitacion para una persona"));
   
        return categorias;
    }
}
