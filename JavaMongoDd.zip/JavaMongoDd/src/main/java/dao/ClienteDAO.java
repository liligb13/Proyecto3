/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author itzel
 */
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mycompany.javamongodd.Cliente;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;

public class ClienteDAO {
    private MongoCollection<Document> collection;

    public ClienteDAO() {
    
        MongoClient mongoClient = new MongoClient("localhost", 27017);

       
        MongoDatabase database = mongoClient.getDatabase("Proyecto3");
        collection = database.getCollection("clientes");
    }
public List<Cliente> obtenerClientes() {
        List<Cliente> clientes = new ArrayList<>();

       
        FindIterable<Document> result = collection.find();

       
        MongoCursor<Document> iterator = result.iterator();
        while (iterator.hasNext()) {
            Document document = iterator.next();
            Cliente cliente = new Cliente(
                    document.getString("id"),
                    document.getString("nombre"),
                    document.getString("apellido"),
                    document.getString("correo")
            );
            clientes.add(cliente);
        }

        return clientes;
    }
    public void insertarCliente(String nombre, String apellido, String correo) {
      
        Document cliente = new Document("nombre", nombre)
                .append("apellido", apellido)
                .append("correo", correo);

       
        collection.insertOne(cliente);
    }

   // Consulta todos los clientes en la colección
    public void consultarClientes() {
        FindIterable<Document> clientes = collection.find();
        for (Document cliente : clientes) {
            System.out.println(cliente.toJson());
        }
    }

    // Consulta un cliente por su correo
    public void consultarClientePorCorreo(String correo) {
        Document cliente = collection.find(Filters.eq("correo", correo)).first();
        if (cliente != null) {
            System.out.println(cliente.toJson());
        } else {
            System.out.println("Cliente no encontrado");
        }
    }

    // Actualiza la información de un cliente por su correo
    public void actualizarCliente(String correo, String nuevoNombre, String nuevoApellido) {
        Document filtro = new Document("correo", correo);
        Document actualizacion = new Document("$set", new Document("nombre", nuevoNombre).append("apellido", nuevoApellido));
        collection.updateOne(filtro, actualizacion);
    }

    // Elimina un cliente por su correo
    public void eliminarCliente(String correo) {
        collection.deleteOne(Filters.eq("correo", correo));
    }
}




