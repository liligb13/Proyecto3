/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author itzel
 */
import com.mycompany.javamongodd.Tarifa;
import java.util.ArrayList;
import java.util.List;

public class TarifaDAO {
    public List<Tarifa> obtenerTarifas() {
        List<Tarifa> tarifas = new ArrayList<>();
        tarifas.add(new Tarifa("656af25e58bd764de8aaccb2", 50.0, "Por Noche",
                               "generadoAutomanticamentePorMongoDBCompass"));
        return tarifas;
    }
}
