/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author itzel
 */
import com.mycompany.javamongodd.Habitacion;
import com.mycompany.javamongodd.Hotel;
import java.util.ArrayList;
import java.util.List;

public class HotelDAO {

    public List<Hotel> obtenerHoteles() {
        List<Hotel> hoteles = new ArrayList<>();

        // Habitaciones para el Hotel San Juan
        List<Habitacion> habitacionesSanJuan = new ArrayList<>();
       
        // Hotel San Juan
        Hotel hotelSanJuan = new Hotel("656af01958bd764de8aacca5", "Hotel San Juan",
                "123 Calle Principal", habitacionesSanJuan);
        hoteles.add(hotelSanJuan);

        return hoteles;
    }
}
