/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author itzel
 */
import com.mycompany.javamongodd.Habitacion;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class HabitacionDAO {
    private List<Habitacion> habitaciones;

    public HabitacionDAO() {
        this.habitaciones = new ArrayList<>();
        habitaciones.add(new Habitacion("Individual", 100.0));
        habitaciones.add(new Habitacion("Doble", 150.0));
    }

    public List<Habitacion> obtenerHabitaciones() {
        // Devuelve todas las habitaciones disponibles
        return habitaciones.stream()
                .filter(Habitacion::isDisponible)
                .collect(Collectors.toList());
    }

    public boolean reservarHabitacion(String tipoHabitacion) {
        // Encuentra la habitación por tipo y la reserva
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.getTipo().equalsIgnoreCase(tipoHabitacion) && habitacion.isDisponible()) {
                habitacion.reservar();
                return true; 
            }
        }
        return false; 
}}


