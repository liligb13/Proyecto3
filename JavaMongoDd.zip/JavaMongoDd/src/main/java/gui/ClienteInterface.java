/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import com.mycompany.javamongodd.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ClienteInterface extends JPanel {

    private JButton agregarClienteButton;
    private JTable clienteTable;
    private ActionListener agregarClienteListener;

    public ClienteInterface() {
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        agregarClienteButton = new JButton("Agregar Cliente");
        clienteTable = new JTable(new DefaultTableModel(
                new Object[]{"ID", "Nombre", "Apellido", "Correo"},
                0));

        JScrollPane scrollPane = new JScrollPane(clienteTable);
        add(scrollPane);

        JButton agregarButton = new JButton("Agregar Cliente");
        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarCliente();
            }
        });
        JButton eliminarButton = new JButton("Eliminar Cliente");
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarCliente();
            }
        });
        add(eliminarButton);

        JButton editarButton = new JButton("Editar Cliente");
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarCliente();
            }
        });
        add(editarButton);
        add(agregarClienteButton);
        add(agregarButton);
    }

    public void actualizarClientes(List<Cliente> clientes) {
        DefaultTableModel model = (DefaultTableModel) clienteTable.getModel();
        model.setRowCount(0);

        for (Cliente cliente : clientes) {
            model.addRow(new Object[]{
                cliente.getId(),
                cliente.getNombre(),
                cliente.getApellido(),
                cliente.getCorreo()
            });
        }
    }

   
    private void agregarCliente() {
        String nombre = JOptionPane.showInputDialog("Nombre:");
        String apellido = JOptionPane.showInputDialog("Apellido:");
        String correo = JOptionPane.showInputDialog("Correo:");

        if (nombre == null || nombre.isEmpty() || apellido == null || apellido.isEmpty()
                || correo == null || correo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios. Por favor, ingrese información en todos los campos.");
            return;
        }

        if (contieneNumeros(nombre) || contieneNumeros(apellido)) {
            JOptionPane.showMessageDialog(this, "El nombre y el apellido no deben contener números.");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) clienteTable.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            String existingCorreo = (String) model.getValueAt(i, 3); // Índice 3 para la columna "Correo"
            if (correo.equalsIgnoreCase(existingCorreo)) {
                JOptionPane.showMessageDialog(this, "El correo ya existe. Ingrese uno diferente.");
                return;
            }
        }

        Cliente nuevoCliente = new Cliente(generarIdUnico(), nombre, apellido, correo);
        model.addRow(new Object[]{
            nuevoCliente.getId(),
            nuevoCliente.getNombre(),
            nuevoCliente.getApellido(),
            nuevoCliente.getCorreo()
        });

        JOptionPane.showMessageDialog(this, "Cliente registrado con éxito.");
// Cerrar la ventana después de agregar un cliente
        JFrame clienteFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
        clienteFrame.dispose();

        
    }

    private void eliminarCliente() {
        String idAEliminar = JOptionPane.showInputDialog("ID del Cliente a Eliminar:");

        if (idAEliminar == null || idAEliminar.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un ID válido.");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) clienteTable.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            String clienteId = (String) model.getValueAt(i, 0); // Índice 0 para la columna "ID"
            if (idAEliminar.equalsIgnoreCase(clienteId)) {
                model.removeRow(i);
                JOptionPane.showMessageDialog(this, "Cliente eliminado con éxito.");
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "No se encontró un cliente con el ID proporcionado.");
    }

    private void editarCliente() {
        String idAEditar = JOptionPane.showInputDialog("ID del Cliente a Editar:");

        if (idAEditar == null || idAEditar.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un ID válido.");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) clienteTable.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            String clienteId = (String) model.getValueAt(i, 0); // Índice 0 para la columna "ID"
            if (idAEditar.equalsIgnoreCase(clienteId)) {
                String nuevoNombre = JOptionPane.showInputDialog("Nuevo Nombre:");
                String nuevoApellido = JOptionPane.showInputDialog("Nuevo Apellido:");
                String nuevoCorreo = JOptionPane.showInputDialog("Nuevo Correo:");

                if (nuevoNombre == null || nuevoNombre.isEmpty() || nuevoApellido == null || nuevoApellido.isEmpty()
                        || nuevoCorreo == null || nuevoCorreo.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios. Por favor, ingrese información en todos los campos.");
                    return;
                }

                if (contieneNumeros(nuevoNombre) || contieneNumeros(nuevoApellido)) {
                    JOptionPane.showMessageDialog(this, "El nombre y el apellido no deben contener números.");
                    return;
                }

                String existingCorreo = (String) model.getValueAt(i, 3); // Índice 3 para la columna "Correo"
                if (!nuevoCorreo.equalsIgnoreCase(existingCorreo)) {
                    for (int j = 0; j < model.getRowCount(); j++) {
                        if (j != i) {
                            String existingCorreoEnTabla = (String) model.getValueAt(j, 3);
                            if (nuevoCorreo.equalsIgnoreCase(existingCorreoEnTabla)) {
                                JOptionPane.showMessageDialog(this, "El correo ya existe. Ingrese uno diferente.");
                                return;
                            }
                        }
                    }
                }

                model.setValueAt(nuevoNombre, i, 1); // Índice 1 para la columna "Nombre"
                model.setValueAt(nuevoApellido, i, 2); // Índice 2 para la columna "Apellido"
                model.setValueAt(nuevoCorreo, i, 3); // Índice 3 para la columna "Correo"

                JOptionPane.showMessageDialog(this, "Cliente editado con éxito.");
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "No se encontró un cliente con el ID proporcionado.");
    }

    private boolean contieneNumeros(String texto) {
        return texto.matches(".*\\d.*");
    }

    private String generarIdUnico() {
        return "ID_" + System.currentTimeMillis();
    }
}
