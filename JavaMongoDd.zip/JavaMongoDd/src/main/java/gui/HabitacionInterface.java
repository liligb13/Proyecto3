/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import com.mycompany.javamongodd.Habitacion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HabitacionInterface extends JPanel {

    private JList<String> habitacionList;
    private JButton agregarButton;
    private ActionListener agregarHabitacionListener;

    public HabitacionInterface() {
        setLayout(new BorderLayout());

        // Configurar la lista de habitaciones
        DefaultListModel<String> habitacionListModel = new DefaultListModel<>();
        habitacionListModel.addElement("Habitación 101 - Individual");
        habitacionListModel.addElement("Habitación 102 - Doble");
        // Agregar más elementos según sea necesario

        habitacionList = new JList<>(habitacionListModel);
        JScrollPane scrollPane = new JScrollPane(habitacionList);
        add(scrollPane, BorderLayout.CENTER);

        // Configurar el botón de agregar
        agregarButton = new JButton("Agregar Habitación");
        agregarButton.addActionListener(e -> agregarHabitacion());
        add(agregarButton, BorderLayout.SOUTH);
    }

    public void setAgregarHabitacionListener(ActionListener listener) {
        this.agregarHabitacionListener = listener;
    }

    private void agregarHabitacion() {
        if (agregarHabitacionListener != null) {
            agregarHabitacionListener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));
        }

        DefaultListModel<String> model = (DefaultListModel<String>) habitacionList.getModel();
        model.addElement("Nueva Habitación - Tipo");
    }
}