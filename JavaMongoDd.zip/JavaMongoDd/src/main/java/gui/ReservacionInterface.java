/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import com.mycompany.javamongodd.Habitacion;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class ReservacionInterface extends JPanel {

    private final JTable reservacionTable;
    private final JButton hacerReservacionButton;
    private final JDateChooser fechaInicioPicker;
    private final JDateChooser fechaFinPicker;
    private final JComboBox<String> tipoClienteComboBox;
    private final JComboBox<String> habitacionComboBox;
    private ActionListener hacerReservacionListener;
    private JLabel nombreClienteLabel;
    private final List<Habitacion> habitaciones;
    private static int contadorReservaciones = 1;

    public ReservacionInterface() {
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        // Crear la etiqueta para mostrar el nombre del cliente
        nombreClienteLabel = new JLabel("Nombre del Cliente: ");
        add(nombreClienteLabel);
        // Inicializar lista de habitaciones
        habitaciones = new ArrayList<>();
        habitaciones.add(new Habitacion("Individual", 50.0));
        habitaciones.add(new Habitacion("Matrimonial", 100.0));

        // Crear tabla para mostrar reservaciones
        reservacionTable = new JTable(new DefaultTableModel(
                new Object[]{"ID", "Fecha Inicio", "Fecha Fin", "Monto Total", "Cliente/Agencia", "Habitación"},
                0));

        // Agregar la tabla a un JScrollPane para permitir desplazamiento
        JScrollPane scrollPane = new JScrollPane(reservacionTable);
        add(scrollPane);

        // Crear el selector de fechas para la Fecha de Inicio
        fechaInicioPicker = new JDateChooser();

        // Crear el selector de fechas para la Fecha de Fin
        fechaFinPicker = new JDateChooser();

        // Crear el combo box para seleccionar el tipo de cliente (Cliente o Agencia de Viajes)
        tipoClienteComboBox = new JComboBox<>();
        tipoClienteComboBox.addItem("Cliente");
        tipoClienteComboBox.addItem("Agencia de Viajes");

        // Crear el combo box para seleccionar la habitación
        habitacionComboBox = new JComboBox<>();
        for (Habitacion habitacion : habitaciones) {
            habitacionComboBox.addItem(habitacion.getTipo());
        }

        hacerReservacionButton = new JButton("Hacer Reservación");
        hacerReservacionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                hacerReservacion();
            }
        });

        // Agregar componentes al panel
        add(new JLabel("Fecha Inicio:"));
        add(fechaInicioPicker);
        add(new JLabel("Fecha Fin:"));
        add(fechaFinPicker);
        add(new JLabel("Seleccione Tipo de Cliente:"));
        add(tipoClienteComboBox);
        add(new JLabel("Seleccione Habitación:"));
        add(habitacionComboBox);
        add(hacerReservacionButton);
    }

    public void actualizarInfoCliente(String nombreCliente) {
        nombreClienteLabel.setText("Nombre del Cliente: " + nombreCliente);
    }

    public void setHacerReservacionListener(ActionListener listener) {
        hacerReservacionListener = listener;
    }

    public String getTipoClienteSeleccionado() {
        return tipoClienteComboBox.getSelectedItem().toString();
    }

    private String obtenerIdReservacion() {
        return "RES_" + contadorReservaciones++;
    }

    private void hacerReservacion() {
        if (hacerReservacionListener != null) {
            hacerReservacionListener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));

        // Obtener fecha de inicio seleccionada
        LocalDate fechaInicio = LocalDate.ofInstant(fechaInicioPicker.getDate().toInstant(), ZoneId.systemDefault());

        // Obtener fecha de fin seleccionada
        LocalDate fechaFin = LocalDate.ofInstant(fechaFinPicker.getDate().toInstant(), ZoneId.systemDefault());

        // Validar que se haya seleccionado una fecha de inicio
        if (fechaInicio
                == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una fecha de inicio válida.");
            return;
        }

        // Validar que se haya seleccionado una fecha de fin
        if (fechaFin
                == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una fecha de fin válida.");
            return;
        }

        // Validar que la fecha de fin sea posterior a la fecha de inicio
        if (fechaFin.isBefore(fechaInicio)) {
            JOptionPane.showMessageDialog(this, "La fecha de fin debe ser posterior a la fecha de inicio.");
            return;
        }

        // Obtener la habitación seleccionada
        String tipoHabitacion = habitacionComboBox.getSelectedItem().toString();
        Habitacion habitacionSeleccionada = null;

        // Buscar la habitación en la lista
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.getTipo().equals(tipoHabitacion) && habitacion.isDisponible()) {
                habitacionSeleccionada = habitacion;
                break;
            }
        }

        // Validar que se haya encontrado una habitación disponible
        if (habitacionSeleccionada
                == null) {
            JOptionPane.showMessageDialog(this, "No hay habitaciones disponibles para el tipo seleccionado.");
            return;
        }

        // Reservar la habitación
        habitacionSeleccionada.reservar();

        // Calcular el número de días de la reserva
        long diff = ChronoUnit.DAYS.between(fechaInicio, fechaFin);

        // Calcular el monto total según el tipo de habitación
        double montoTotal = diff * habitacionSeleccionada.getTarifa();

        // Obtener el tipo de cliente seleccionado
        String tipoCliente = tipoClienteComboBox.getSelectedItem().toString();

        // Agregar la nueva reservación a la tabla
        DefaultTableModel model = (DefaultTableModel) reservacionTable.getModel();

        model.addRow(
                new Object[]{
                    obtenerIdReservacion(),
                    fechaInicio,
                    fechaFin,
                    montoTotal,
                    tipoCliente,
                    tipoHabitacion
                }
        );

        // Informar al usuario
        JOptionPane.showMessageDialog(this,
                "Reservación realizada con éxito. Monto Total: $" + montoTotal);

        // Reiniciar las fechas
        fechaInicioPicker.setDate(
                null);
        fechaFinPicker.setDate(
                null);
    }

}}
