/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author itzel
 */
import com.mycompany.javamongodd.Cliente;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class PrincipalInterface extends JFrame {

    private ReservacionInterface reservacionInterface;
    private ClienteInterface clienteInterface;
    private HabitacionInterface habitacionInterface;

    private List<Cliente> clientes;
    private List<String> habitaciones;

    public PrincipalInterface() {

        setTitle("Sistema de Reservaciones");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        clientes = new ArrayList<>();
        habitaciones = new ArrayList<>();

        reservacionInterface = new ReservacionInterface();
        clienteInterface = new ClienteInterface();
        habitacionInterface = new HabitacionInterface();

        
        reservacionInterface.setHacerReservacionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                String tipoCliente = reservacionInterface.getTipoClienteSeleccionado();

               
                if ("Cliente".equals(tipoCliente)) {
                   
                } else if ("Agencia de Viajes".equals(tipoCliente)) {
                    
                }
            }
        });

        habitacionInterface.setAgregarHabitacionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nuevaHabitacion = JOptionPane.showInputDialog("Nombre de la Nueva Habitación:");
                if (nuevaHabitacion != null && !nuevaHabitacion.isEmpty()) {
                    habitaciones.add(nuevaHabitacion);
                }
            }
        });

        add(reservacionInterface, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null); 
 
        SwingUtilities.invokeLater(() -> {
            JFrame clienteFrame = new JFrame("Datos del Cliente");
            clienteFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            clienteFrame.getContentPane().add(clienteInterface);
            clienteFrame.pack();
            clienteFrame.setVisible(true);
        });
    }
    private String generarIdUnico() {
        return "ID_" + System.currentTimeMillis();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PrincipalInterface principal = new PrincipalInterface();
            principal.setVisible(true);
        });
    }
}
